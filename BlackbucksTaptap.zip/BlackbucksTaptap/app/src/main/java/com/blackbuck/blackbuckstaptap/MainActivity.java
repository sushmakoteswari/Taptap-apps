package com.blackbuck.blackbuckstaptap;

import static com.blackbuck.blackbuckstaptap.Constants.TOPIC;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.blackbuck.blackbuckstaptap.model.ApiUtilities;
import com.blackbuck.blackbuckstaptap.model.NotificationData;
import com.blackbuck.blackbuckstaptap.model.PushNotification;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private EditText title,message;
    private Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        title = findViewById(androidx.core.R.id.title);
        message = findViewById(androidx.appcompat.R.id.message);

        button.setOnClickListener(v -> {
            String titleTxt = title.getText().toString();
            String msgTxt = message.getText().toString();

            if(!titleTxt.isEmpty() && !msgTxt.isEmpty()) {
                PushNotification notification = new PushNotification(new NotificationData(titleTxt, msgTxt), TOPIC);
                sendNotification(notification);
            }

    });
}

    private void sendNotification(PushNotification notification) {
        ApiUtilities.getClient().sendNotification(notification).enqueue(new Callback<PushNotification>() {
            @Override
            public void onResponse(Call<PushNotification> call, Response<PushNotification> response) {
                if(response.isSuccessful())
                    Toast.makeText(MainActivity.this,"success",Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this,"error",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<PushNotification> call, Throwable t) {
                Toast.makeText(MainActivity.this,t.getMessage(),Toast.LENGTH_SHORT).show();

            }
        });
    }
}