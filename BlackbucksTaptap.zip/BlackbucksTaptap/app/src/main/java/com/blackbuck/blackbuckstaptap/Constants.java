package com.blackbuck.blackbuckstaptap;

public class Constants {
    public static final String BASE_URL = "https://fcm.googleapis.com";
    public static final String SERVER_KEY = "AAAAbpldKLA:APA91bFYOiGSSsE3OpG5W95EE05SMYZX-Iv6Xdgqd139eZ9s-kxQqS0OFGlgxq4ewLDLIEg12GYVvdtOH7gooXNo5uzqyrvoXwtks4mSylfL358rJGZXWZY2HuawSJAIdYwIA2rV1jQI";
    public static final String CONTENT_TYPE = "application/json";
    public static final String TOPIC = "/topics/taptap";

}
