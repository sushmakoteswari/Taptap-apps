package com.blackbuck.model.retrofitutil;

import retrofit2.Retrofit;

public class ApiClient  {
    private static final String BASE_URL="";
    private static Retrofit retrofit=null;

}
