package com.blackbuck.taptapp.model;

public class Constant {
    public static final String TOPIC = "/topics/taptap";

}
