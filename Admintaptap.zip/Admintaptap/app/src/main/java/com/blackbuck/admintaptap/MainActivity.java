package com.blackbuck.admintaptap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String[] items = {"IIDT","DIET","RIET","NRIT","Potti Sree Ramulu"};
    String[] courses = {"C","C++","Power Hundred","Java","Hackathon"};
    AutoCompleteTextView autoCompleteTxt;
    AutoCompleteTextView autoComplete;
    ArrayAdapter<String> adapterItems;
    ArrayAdapter<String> adapterCourses;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        autoCompleteTxt = findViewById(R.id.auto_complete_txt);
        autoComplete = findViewById(R.id.auto_complete);
        adapterItems = new ArrayAdapter<String>(this,R.layout.list_item,items);
        adapterCourses=new ArrayAdapter<String>(this,R.layout.list_courses,courses);


        autoCompleteTxt.setAdapter(adapterItems);
        autoComplete.setAdapter(adapterCourses);
        autoCompleteTxt.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(), "Item: "+item,Toast.LENGTH_SHORT).show();
            }
        });
        autoComplete.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(), "Courses: "+courses,Toast.LENGTH_SHORT).show();
            }
        });

    }
}